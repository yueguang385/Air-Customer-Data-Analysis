package com.test.ML.MyKmeans;
import com.test.ML.MyKmeans.Point;
import com.test.ML.MyKmeans.Cluster;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;


public class Kmeans {
	public List<Point>points;
	FileWriter out1 = null;
	FileWriter out2 = null;
	FileWriter out3 = null;
	FileWriter out4 = null;
	FileWriter out5 = null;
	FileWriter out6 = null;
	
	public int numCluster = 5;
	public int numIterator = 20000;
	public int numPoints = 62044;
	public Cluster cluster;//用于执行聚类的Cluster类对象
	public List<Point>cluster1=new ArrayList<Point>();
	public List<Point>cluster2=new ArrayList<Point>();
	public List<Point>cluster3=new ArrayList<Point>();
	public List<Point>cluster4=new ArrayList<Point>();
	public List<Point>cluster5=new ArrayList<Point>();


	public Kmeans(int numPoints, int cluster_number, int iterrator_number) {
        this.numPoints = numPoints;
        this.numCluster = cluster_number;
        this.numIterator = iterrator_number;
    }

	public static void main(String[] args) throws IOException
    {
        //指定点集个数，簇的个数，迭代次数
        Kmeans kmeans = new Kmeans(62044, 5, 2000);

        //初始化点集、KMeansCluster对象
        kmeans.init();
        //使用KMeansCluster对象进行聚类
        kmeans.runKmeans();

        kmeans.printRes();
        kmeans.Classify();
        kmeans.saveResToFile();
       
        
    }
	private void init() throws IOException
    {
        this.initPoints();
        cluster = new Cluster(numCluster, numIterator, points);
    }
	private void runKmeans()
    {
        cluster.runKmeans();
    }

	public void initPoints() throws IOException
    {
        points = new ArrayList<Point>(numPoints);
        String path = "F://kmeans//result.txt";
        Reader fr=new FileReader(path);//里氏替换，将子类的实例赋予父类的对象
		BufferedReader br=new BufferedReader(fr);
		String line=null;
		while((line=br.readLine())!=null) {
			String []propers=line.split(",");
			long id=Long.parseLong(propers[0]);
			double li=Double.parseDouble(propers[1]);
			double ri=Double.parseDouble(propers[2]);
			double fi=Double.parseDouble(propers[3]);
			double mS=Double.parseDouble(propers[4]);
			double ci=Double.parseDouble(propers[5]);
			Point tmpPoint=new Point(id, li, ri, fi, mS, ci);
			points.add(tmpPoint);		
		}
        br.close();
        fr.close();
    }
	
	 public void printRes()
	    {

	        System.out.println("==================Centers-I====================");
	        for (Point center : cluster.centers)
	        {
	            System.out.println(center.toString());
	        }

//	        System.out.println("==================Points====================");
//
//	        for (Point point : points)
//	        {
//	            System.out.println(point.toString());
//	        }
	        
	    }

	    public void saveResToFile()
	    {
	        try
	        {
	            out1 = new FileWriter(new File("F://kmeans//cluster1.txt"));
                BufferedWriter bufferedWriter1 = new BufferedWriter(out1);
	            for (Point point : cluster1)
	            {
	                bufferedWriter1.write(point.getId()+" ");
	                bufferedWriter1.newLine();
	                bufferedWriter1.flush();
	            }
	            out1.close();
	            bufferedWriter1.close();
	            
	            out2 = new FileWriter(new File("F://kmeans//cluster2.txt"));
                BufferedWriter bufferedWriter2 = new BufferedWriter(out2);
	            for (Point point : cluster2)
	            {
	                bufferedWriter2.write(point.getId()+" ");
	                bufferedWriter2.newLine();
	                bufferedWriter2.flush();
	            }
	            out2.close();
	            bufferedWriter2.close();
	            
	            out3 = new FileWriter(new File("F://kmeans//cluster3.txt"));
                BufferedWriter bufferedWriter3 = new BufferedWriter(out3);
	            for (Point point : cluster3)
	            {
	                bufferedWriter3.write(point.getId()+" ");
	                bufferedWriter3.newLine();
	                bufferedWriter3.flush();
	            }
	            out3.close();
	            bufferedWriter3.close();
	            
	            out4 = new FileWriter(new File("F://kmeans//cluster4.txt"));
                BufferedWriter bufferedWriter4 = new BufferedWriter(out4);
	            for (Point point : cluster4)
	            {
	                bufferedWriter4.write(point.getId()+" ");
	                bufferedWriter4.newLine();
	                bufferedWriter4.flush();
	            }
	            out4.close();            
	            bufferedWriter4.close();
	            
	            out5 = new FileWriter(new File("F://kmeans//cluster5.txt"));
                BufferedWriter bufferedWriter5 = new BufferedWriter(out5);
	            for (Point point : cluster5)
	            {
	                bufferedWriter5.write(point.getId()+" ");
	                bufferedWriter5.newLine();
	                bufferedWriter5.flush();
	            }
	            out5.close();
	            bufferedWriter5.close();
	            
	            out6 = new FileWriter(new File("F://kmeans//center.txt"));
                BufferedWriter bufferedWriter6 = new BufferedWriter(out6);
	            for (Point point : cluster.centers)
	            {
	                bufferedWriter6.write(point.getId()+","+(point.getLi()-12)/102+","+(point.getRi()-1)/23+","+(point.getFi()-2)/211+","+(point.getMS()-368)/580349+","+(point.getCi()-0.136)/1.364+","+point.getCla());
	                bufferedWriter6.newLine();
	                bufferedWriter6.flush();
	            }
	            out6.close();
	            bufferedWriter6.close();

	        } catch (IOException e)
	        {
	            e.printStackTrace();
	        }
	    }
	    public void Classify() {
	    	int num1=0;
	    	int num2=0;
	    	int num3=0;
	    	int num4=0;
	    	int num5=0;
	    	for(Point point:points) {
	    		if(point.getCla()==1) {cluster1.add(point);num1++;}
	    		if(point.getCla()==2) {cluster2.add(point);num2++;}
	    		if(point.getCla()==3) {cluster3.add(point);num3++;}
	    		if(point.getCla()==4) {cluster4.add(point);num4++;}
	    		if(point.getCla()==5) {cluster5.add(point);num5++;}    		
	    	}
	    	System.out.println(num1);
	    	System.out.println(num2);
	    	System.out.println(num3);
	    	System.out.println(num4);
	    	System.out.println(num5);
	    	
	    }




}
