package com.test.provincesanalyze.entity;

import java.util.List;

public class MyDataOfAge {
	List<Integer> Class1Data;
	List<String> Class1Age;
	List<Integer> Class2Data;
	List<String> Class2Age;
	List<Integer> Class3Data;
	List<String> Class3Age;
	List<Integer> Class4Data;
	List<String> Class4Age;
	List<Integer> Class5Data;
	List<String> Class5Age;
	public MyDataOfAge() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MyDataOfAge(List<Integer> class1Data, List<String> class1Age, List<Integer> class2Data,
			List<String> class2Age, List<Integer> class3Data, List<String> class3Age, List<Integer> class4Data,
			List<String> class4Age, List<Integer> class5Data, List<String> class5Age) {
		super();
		Class1Data = class1Data;
		Class1Age = class1Age;
		Class2Data = class2Data;
		Class2Age = class2Age;
		Class3Data = class3Data;
		Class3Age = class3Age;
		Class4Data = class4Data;
		Class4Age = class4Age;
		Class5Data = class5Data;
		Class5Age = class5Age;
	}
	public List<Integer> getClass1Data() {
		return Class1Data;
	}
	public void setClass1Data(List<Integer> class1Data) {
		Class1Data = class1Data;
	}
	public List<String> getClass1Age() {
		return Class1Age;
	}
	public void setClass1Age(List<String> class1Age) {
		Class1Age = class1Age;
	}
	public List<Integer> getClass2Data() {
		return Class2Data;
	}
	public void setClass2Data(List<Integer> class2Data) {
		Class2Data = class2Data;
	}
	public List<String> getClass2Age() {
		return Class2Age;
	}
	public void setClass2Age(List<String> class2Age) {
		Class2Age = class2Age;
	}
	public List<Integer> getClass3Data() {
		return Class3Data;
	}
	public void setClass3Data(List<Integer> class3Data) {
		Class3Data = class3Data;
	}
	public List<String> getClass3Age() {
		return Class3Age;
	}
	public void setClass3Age(List<String> class3Age) {
		Class3Age = class3Age;
	}
	public List<Integer> getClass4Data() {
		return Class4Data;
	}
	public void setClass4Data(List<Integer> class4Data) {
		Class4Data = class4Data;
	}
	public List<String> getClass4Age() {
		return Class4Age;
	}
	public void setClass4Age(List<String> class4Age) {
		Class4Age = class4Age;
	}
	public List<Integer> getClass5Data() {
		return Class5Data;
	}
	public void setClass5Data(List<Integer> class5Data) {
		Class5Data = class5Data;
	}
	public List<String> getClass5Age() {
		return Class5Age;
	}
	public void setClass5Age(List<String> class5Age) {
		Class5Age = class5Age;
	}
	
	

}
