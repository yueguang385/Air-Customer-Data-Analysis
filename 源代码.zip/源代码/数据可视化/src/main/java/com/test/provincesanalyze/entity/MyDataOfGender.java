package com.test.provincesanalyze.entity;

import java.util.List;

public class MyDataOfGender {
	List<Integer> men;
	List<Integer> women;
	List<Double> ratiomen;
	List<Double> ratiowomen;
	public MyDataOfGender() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MyDataOfGender(List<Integer> men, List<Integer> women, List<Double> ratiomen, List<Double> ratiowomen) {
		super();
		this.men = men;
		this.women = women;
		this.ratiomen = ratiomen;
		this.ratiowomen = ratiowomen;
	}
	public List<Integer> getMen() {
		return men;
	}
	public void setMen(List<Integer> men) {
		this.men = men;
	}
	public List<Integer> getWomen() {
		return women;
	}
	public void setWomen(List<Integer> women) {
		this.women = women;
	}
	public List<Double> getRatiomen() {
		return ratiomen;
	}
	public void setRatiomen(List<Double> ratiomen) {
		this.ratiomen = ratiomen;
	}
	public List<Double> getRatiowomen() {
		return ratiowomen;
	}
	public void setRatiowomen(List<Double> ratiowomen) {
		this.ratiowomen = ratiowomen;
	}
}