package com.test.provincesanalyze.web.controller;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.Cluster;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.provincesanalyze.entity.MyData;
import com.test.provincesanalyze.entity.MyDataOfAge;
import com.test.provincesanalyze.entity.MyDataOfGender;
import com.test.provincesanalyze.entity.MyDataOfProvinces;
import com.test.provincesanalyze.utils.DatFileUtil;

@RestController
public class RemoteDataController {
	
	private MyData fillDatas(String pathname, String filename) throws IOException {
		MyData myData = new MyData();
		List<Double> data1 = new ArrayList<Double>();
		List<Double> data2 = new ArrayList<Double>();
		List<Double> data3 = new ArrayList<Double>();
		List<Double> data4 = new ArrayList<Double>();
		List<Double> data5 = new ArrayList<Double>();
		
		FileReader reader = DatFileUtil.getFileReader(pathname, filename);
		int i = 0;
		if(filename == "centerinfo.txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    

			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split(",");
				    if(i == 0) {
				    	for(int j = 1;j<=5;j++)
				    	  data1.add(Double.parseDouble(strs[j]));
				    	myData.setClass1Data(data1);
				    }
				    if(i == 1) {
				    	for(int k = 1;k<=5;k++)
				    	  data2.add(Double.parseDouble(strs[k]));
				    	myData.setClass2Data(data2);
				    }
				    if(i == 2) {
				    	for(int l = 1;l<=5;l++)
				    	  data3.add(Double.parseDouble(strs[l]));
				    	myData.setClass3Data(data3);
				    }
				    if(i == 3) {
				    	for(int m = 1;m<=5;m++)
				    	  data4.add(Double.parseDouble(strs[m]));
				    	myData.setClass4Data(data4);
				    }
				    if(i == 4) {
				    	for(int n = 1;n<=5;n++)
				    	  data5.add(Double.parseDouble(strs[n]));
				    	myData.setClass5Data(data5);
				    }
				   i=i+1;
			    }	
		    }
		}
		return myData;
	}
	
	private MyDataOfProvinces fillDatas1(String pathname, String filename) throws IOException {
		MyDataOfProvinces myData = new MyDataOfProvinces();
		List<Integer> data1 = new ArrayList<Integer>();
		List<Integer> data2 = new ArrayList<Integer>();
		List<Integer> data3 = new ArrayList<Integer>();
		List<Integer> data4 = new ArrayList<Integer>();
		List<Integer> data5 = new ArrayList<Integer>();
		
		List<String> pro1 = new ArrayList<String>();
		List<String> pro2 = new ArrayList<String>();
		List<String> pro3 = new ArrayList<String>();
		List<String> pro4 = new ArrayList<String>();
		List<String> pro5 = new ArrayList<String>();
		FileReader reader = DatFileUtil.getFileReader(pathname, filename);
		
		if(filename == "cluster1(1).txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data1.add(Integer.parseInt(strs[1]));
				    pro1.add(strs[0]);
				    }  
			    }
		    myData.setClass1Data(data1);
		    myData.setClass1Provinces(pro1);
		    }
		if(filename == "cluster2(1).txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data2.add(Integer.parseInt(strs[1]));
				    pro2.add(strs[0]);
				    }  
			    }
		    myData.setClass2Data(data2);
		    myData.setClass2Provinces(pro2);
		    }
		if(filename == "cluster3(1).txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data3.add(Integer.parseInt(strs[1]));
				    pro3.add(strs[0]);
				    }  
			    }
		    myData.setClass3Data(data3);
		    myData.setClass3Provinces(pro3);
		    }
		if(filename == "cluster4(1).txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data4.add(Integer.parseInt(strs[1]));
				    pro4.add(strs[0]);
				    }  
			    }
		    myData.setClass4Data(data4);
		    myData.setClass4Provinces(pro4);
		    }
		if(filename == "cluster5(1).txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data5.add(Integer.parseInt(strs[1]));
				    pro5.add(strs[0]);
				    }  
			    }
		    myData.setClass5Data(data5);
		    myData.setClass5Provinces(pro5);
		    }
		
		return myData;
		}
	
	@GetMapping("/analyzedata")
	public MyData getMyData() throws IOException {

		MyData myData = this.fillDatas("data", "centerinfo.txt");
		return myData;
	}
	
	@GetMapping("/analyzeprovincesdata")
	public MyDataOfProvinces getMyData2() throws IOException {

		MyDataOfProvinces myData = this.fillDatas1("data", "cluster1(1).txt");
		MyDataOfProvinces myData1 = this.fillDatas1("data", "cluster2(1).txt");
		MyDataOfProvinces myData2 = this.fillDatas1("data", "cluster3(1).txt");
		MyDataOfProvinces myData3 = this.fillDatas1("data", "cluster4(1).txt");
		MyDataOfProvinces myData4 = this.fillDatas1("data", "cluster5(1).txt");
		myData.setClass2Data(myData1.getClass2Data());
		myData.setClass2Provinces(myData1.getClass2Provinces());
		myData.setClass3Data(myData2.getClass3Data());
		myData.setClass3Provinces(myData2.getClass3Provinces());
		myData.setClass4Data(myData3.getClass4Data());
		myData.setClass4Provinces(myData3.getClass4Provinces());
		myData.setClass5Data(myData4.getClass5Data());
		myData.setClass5Provinces(myData4.getClass5Provinces());
		return myData;
	}

	private MyDataOfGender fillDatas2(String pathname, String filename) throws IOException {
		MyDataOfGender myData = new MyDataOfGender();
		List<Integer> men = new ArrayList<Integer>();
		List<Integer> women = new ArrayList<Integer>();
		FileReader reader = DatFileUtil.getFileReader(pathname, filename);
		
	    if (reader != null) {
		    LineNumberReader lineReader = new LineNumberReader(reader);
		    String line = "";
		    
	        line = lineReader.readLine(); 
		    String[] strs = line.split("\t");
		    women.add(Integer.parseInt(strs[1]));
		    
		    line = lineReader.readLine();
		    strs = line.split("\t");
		    men.add(Integer.parseInt(strs[1]));	
		   
		    }
	    myData.setMen(men);
	    myData.setWomen(women);
		return myData;
	}
	
	@GetMapping("/analyzegenderdata")
	public MyDataOfGender getMyData3() throws IOException {
		MyDataOfGender myData1 = this.fillDatas2("data", "gender1.txt");
		MyDataOfGender myData2 = this.fillDatas2("data", "gender2.txt");
		MyDataOfGender myData3 = this.fillDatas2("data", "gender3.txt");
		MyDataOfGender myData4 = this.fillDatas2("data", "gender4.txt");
		MyDataOfGender myData5 = this.fillDatas2("data", "gender5.txt");
		
		List<Integer> allmen = new ArrayList<Integer>();
		List<Integer> allwomen = new ArrayList<Integer>();
		allmen.add(myData1.getMen().get(0));
		allmen.add(myData2.getMen().get(0));
		allmen.add(myData3.getMen().get(0));
		allmen.add(myData4.getMen().get(0));
		allmen.add(myData5.getMen().get(0));
		allwomen.add(myData1.getWomen().get(0));
		allwomen.add(myData2.getWomen().get(0));
		allwomen.add(myData3.getWomen().get(0));
		allwomen.add(myData4.getWomen().get(0));
		allwomen.add(myData5.getWomen().get(0));
		
		List<Double> aallmen = new ArrayList<Double>();
		List<Double> aallwomen = new ArrayList<Double>();
		int mensum = allmen.get(0)+allmen.get(1)+allmen.get(2)+allmen.get(3)+allmen.get(4);
		int womensum = allwomen.get(0)+allwomen.get(1)+allwomen.get(2)+allwomen.get(3)+allwomen.get(4);
		
		for(int i=0;i<5;i++)
		{
			aallmen.add(allmen.get(i)*1.0/mensum);
			aallwomen.add(allwomen.get(i)*1.0/womensum);
		}
		
		myData1.setRatiomen(aallmen);
		myData1.setRatiowomen(aallwomen);
		
		return myData1;
	}
	
	
	private MyDataOfAge fillDatas3(String pathname, String filename) throws IOException {
		MyDataOfAge myData = new MyDataOfAge();
		List<Integer> data1 = new ArrayList<Integer>();
		List<Integer> data2 = new ArrayList<Integer>();
		List<Integer> data3 = new ArrayList<Integer>();
		List<Integer> data4 = new ArrayList<Integer>();
		List<Integer> data5 = new ArrayList<Integer>();
		
		List<String> pro1 = new ArrayList<String>();
		List<String> pro2 = new ArrayList<String>();
		List<String> pro3 = new ArrayList<String>();
		List<String> pro4 = new ArrayList<String>();
		List<String> pro5 = new ArrayList<String>();
		FileReader reader = DatFileUtil.getFileReader(pathname, filename);
		
		if(filename == "age1.txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data1.add(Integer.parseInt(strs[1]));
				    pro1.add(strs[0]);
				    }  
			    }
		    myData.setClass1Data(data1);
		    myData.setClass1Age(pro1);
		    }
		if(filename == "age2.txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data2.add(Integer.parseInt(strs[1]));
				    pro2.add(strs[0]);
				    }  
			    }
		    myData.setClass2Data(data2);
		    myData.setClass2Age(pro2);
		    }
		if(filename == "age3.txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data3.add(Integer.parseInt(strs[1]));
				    pro3.add(strs[0]);
				    }  
			    }
		    myData.setClass3Data(data3);
		    myData.setClass3Age(pro3);
		    }
		if(filename == "age4.txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data4.add(Integer.parseInt(strs[1]));
				    pro4.add(strs[0]);
				    }  
			    }
		    myData.setClass4Data(data4);
		    myData.setClass4Age(pro4);
		    }
		if(filename == "age5.txt") {
		    if (reader != null) {
			    LineNumberReader lineReader = new LineNumberReader(reader);
			    String line = "";
			    
			    while ((line = lineReader.readLine()) != null) {
				    String[] strs = line.split("\t");
				    data5.add(Integer.parseInt(strs[1]));
				    pro5.add(strs[0]);
				    }  
			    }
		    myData.setClass5Data(data5);
		    myData.setClass5Age(pro5);
		    }
		
		return myData;
		}
	
	@GetMapping("/analyzeagedata")
	public MyDataOfAge getMyData4() throws IOException {

		MyDataOfAge myData = this.fillDatas3("data", "age1.txt");
		MyDataOfAge myData1 = this.fillDatas3("data", "age2.txt");
		MyDataOfAge myData2 = this.fillDatas3("data", "age3.txt");
		MyDataOfAge myData3 = this.fillDatas3("data", "age4.txt");
		MyDataOfAge myData4 = this.fillDatas3("data", "age5.txt");
		myData.setClass2Data(myData1.getClass2Data());
		myData.setClass2Age(myData1.getClass2Age());
		myData.setClass3Data(myData2.getClass3Data());
		myData.setClass3Age(myData2.getClass3Age());
		myData.setClass4Data(myData3.getClass4Data());
		myData.setClass4Age(myData3.getClass4Age());
		myData.setClass5Data(myData4.getClass5Data());
		myData.setClass5Age(myData4.getClass5Age());
		return myData;
	}
}
