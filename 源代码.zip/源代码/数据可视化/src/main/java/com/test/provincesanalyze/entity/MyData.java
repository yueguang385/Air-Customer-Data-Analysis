package com.test.provincesanalyze.entity;

import java.util.List;

import javax.swing.ListModel;

public class MyData {
	List<Double> Class1Data;
	
	List<Double> Class2Data; 
	
	List<Double> Class3Data; 
	
	List<Double> Class4Data; 
	
	List<Double> Class5Data;
	
	public MyData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public MyData(List<Double> class1Data, List<Double> class2Data, List<Double> class3Data, List<Double> class4Data,
			List<Double> class5Data) {
		super();
		Class1Data = class1Data;
		Class2Data = class2Data;
		Class3Data = class3Data;
		Class4Data = class4Data;
		Class5Data = class5Data;
	}



	
	public List<Double> getClass1Data() {
		return Class1Data;
	}
	public void setClass1Data(List<Double> class1Data) {
		Class1Data = class1Data;
	}
	public List<Double> getClass2Data() {
		return Class2Data;
	}
	public void setClass2Data(List<Double> class2Data) {
		Class2Data = class2Data;
	}
	public List<Double> getClass3Data() {
		return Class3Data;
	}
	public void setClass3Data(List<Double> class3Data) {
		Class3Data = class3Data;
	}
	public List<Double> getClass4Data() {
		return Class4Data;
	}
	public void setClass4Data(List<Double> class4Data) {
		Class4Data = class4Data;
	}
	public List<Double> getClass5Data() {
		return Class5Data;
	}
	public void setClass5Data(List<Double> class5Data) {
		Class5Data = class5Data;
	}
	
	
	

}
