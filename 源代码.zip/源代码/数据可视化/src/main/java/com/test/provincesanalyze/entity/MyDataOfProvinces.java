package com.test.provincesanalyze.entity;

import java.util.List;

public class MyDataOfProvinces {
	List<Integer> Class1Data;
	List<String> Class1Provinces;
	List<Integer> Class2Data;
	List<String> Class2Provinces;
	List<Integer> Class3Data;
	List<String> Class3Provinces;
	List<Integer> Class4Data;
	List<String> Class4Provinces;
	List<Integer> Class5Data;
	List<String> Class5Provinces;
	public MyDataOfProvinces() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public MyDataOfProvinces(List<Integer> class1Data, List<String> class1Provinces, List<Integer> class2Data,
			List<String> class2Provinces, List<Integer> class3Data, List<String> class3Provinces,
			List<Integer> class4Data, List<String> class4Provinces, List<Integer> class5Data,
			List<String> class5Provinces) {
		super();
		Class1Data = class1Data;
		Class1Provinces = class1Provinces;
		Class2Data = class2Data;
		Class2Provinces = class2Provinces;
		Class3Data = class3Data;
		Class3Provinces = class3Provinces;
		Class4Data = class4Data;
		Class4Provinces = class4Provinces;
		Class5Data = class5Data;
		Class5Provinces = class5Provinces;
	}

	public List<String> getClass1Provinces() {
		return Class1Provinces;
	}

	public void setClass1Provinces(List<String> class1Provinces) {
		Class1Provinces = class1Provinces;
	}

	public List<String> getClass2Provinces() {
		return Class2Provinces;
	}

	public void setClass2Provinces(List<String> class2Provinces) {
		Class2Provinces = class2Provinces;
	}

	public List<String> getClass3Provinces() {
		return Class3Provinces;
	}

	public void setClass3Provinces(List<String> class3Provinces) {
		Class3Provinces = class3Provinces;
	}

	public List<String> getClass4Provinces() {
		return Class4Provinces;
	}

	public void setClass4Provinces(List<String> class4Provinces) {
		Class4Provinces = class4Provinces;
	}

	public List<String> getClass5Provinces() {
		return Class5Provinces;
	}

	public void setClass5Provinces(List<String> class5Provinces) {
		Class5Provinces = class5Provinces;
	}

	public List<Integer> getClass1Data() {
		return Class1Data;
	}
	public void setClass1Data(List<Integer> class1Data) {
		Class1Data = class1Data;
	}
	public List<Integer> getClass2Data() {
		return Class2Data;
	}
	public void setClass2Data(List<Integer> class2Data) {
		Class2Data = class2Data;
	}
	public List<Integer> getClass3Data() {
		return Class3Data;
	}
	public void setClass3Data(List<Integer> class3Data) {
		Class3Data = class3Data;
	}
	public List<Integer> getClass4Data() {
		return Class4Data;
	}
	public void setClass4Data(List<Integer> class4Data) {
		Class4Data = class4Data;
	}
	public List<Integer> getClass5Data() {
		return Class5Data;
	}
	public void setClass5Data(List<Integer> class5Data) {
		Class5Data = class5Data;
	}
	
	

}
