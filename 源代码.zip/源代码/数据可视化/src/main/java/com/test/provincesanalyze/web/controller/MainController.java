package com.test.provincesanalyze.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
	
	@GetMapping("/classanalyze")
	public String classAnalyze() {
		return "classanalyze";
	}
	
	@GetMapping("/firstclassprovincesanalyze")
	public String firstprovincesAnalyze() {
		return "firstclassprovincesanalyze";
	}
	
	@GetMapping("/secondclassprovincesanalyze")
	public String secondprovincesAnalyze() {
		return "secondclassprovincesanalyze";
	}
	
	@GetMapping("/thirdclassprovincesanalyze")
	public String thirdprovincesAnalyze() {
		return "thirdclassprovincesanalyze";
	}
	
	@GetMapping("/forthclassprovincesanalyze")
	public String forthprovincesAnalyze() {
		return "forthclassprovincesanalyze";
	}
	
	@GetMapping("/fifthclassprovincesanalyze")
	public String fifthprovincesAnalyze() {
		return "fifthclassprovincesanalyze";
	}
	
	@GetMapping("/genderanalyze")
	public String genderAnalyze() {
		return "genderanalyze";
	}
	
	@GetMapping("/firstclassageanalyze")
	public String firstageAnalyze() {
		return "firstclassageanalyze";
	}
	
	@GetMapping("/secondclassageanalyze")
	public String secondageAnalyze() {
		return "secondclassageanalyze";
	}
	
	@GetMapping("/thirdclassageanalyze")
	public String thirdageAnalyze() {
		return "thirdclassageanalyze";
	}
	
	@GetMapping("/forthclassageanalyze")
	public String forthageAnalyze() {
		return "forthclassageanalyze";
	}
	
	@GetMapping("/fifthclassageanalyze")
	public String fifthageAnalyze() {
		return "fifthclassageanalyze";
	}
}
