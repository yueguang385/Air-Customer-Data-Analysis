package com.test.provincesanalyze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyprovincesanalyzeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyprovincesanalyzeApplication.class, args);
	}
	
}
