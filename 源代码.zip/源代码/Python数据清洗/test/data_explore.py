'''
    data_explore.py
'''

#1.导入需要的模块组件
import pandas as pd
import os

#2. 0:数据准备、导入

#2  设置原始数据文件的地址|位置信息
data_file = "air_data.csv"
data_path = os.getcwd() + os.sep + "data" + os.sep + data_file
#使用 pandas 导入数据到
#data = pd.read_csv(data_path, encoding='gb18030')
data = pd.read_csv(data_path)

print(data.head()) #前五行
print(data.info())

explore = data.describe(percentiles=[], include='all').T #数组转置
# explore = data.describe(percentiles=[]).T
#数组转置

#显示全部的dataframe的信息
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('max_colwidth', 100)
print(explore)

#算出原始数据集中每一列空值的数目，放入探查结果的 explore
explore['null'] = len(data) - explore['count']

#统计空值、最大值、最小值的每一列的数量
explore_result = explore[['null', 'max', 'min']]
explore_result.columns = ['空值', '最大值', '最小值']

print(explore_result)

#将结果输出到Excel文件
excel_path = os.getcwd() + os.sep + "out" + os.sep + "explore_result.xls"
#可能需要安装 xlwt 模块
explore_result.to_excel(excel_path)

print(11)