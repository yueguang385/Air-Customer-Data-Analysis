#1.导入需要的模块组件
import pandas as pd
import os

#2. 0:数据准备、导入

#2  设置原始数据文件的地址|位置信息
data_file = "air_data.csv"
data_path = os.getcwd() + os.sep + "data" + os.sep + data_file
#使用 pandas 导入数据到
#data = pd.read_csv(data_path, encoding='gb18030')
data = pd.read_csv(data_path)

#初筛
condition = data['SUM_YR_1'].notnull() & data['SUM_YR_2'].notnull()
data_first_screen = data[condition]
print(data_first_screen.info())
print(data_first_screen.shape)
print(data_first_screen)

#终筛
condition1 = data_first_screen['SUM_YR_1'] != 0
condition2 = data_first_screen['SUM_YR_2'] != 0
condition3 = (data_first_screen['SEG_KM_SUM'] != 0) & (data_first_screen['avg_discount'] != 0)

#bool = data_first_screen.str.contains('CN')
#condition4 = data_first_screen[bool]

#condition4 = data_first_screen['WORK_COUNTRY'] = ('CN' |: 'HK'|: 'TW')
#condition5 = data_first_screen['WORK_COUNTRY'] = 'HK'
#condition6 = data_first_screen['WORK_COUNTRY'] = 'TW'
data_end_screen = data_first_screen[(condition1 | condition2) & condition3]



print(data_end_screen.info())
print(data_end_screen.shape)
print(data_end_screen)

#将结果输出到Excel文件
excel_path = os.getcwd() + os.sep + "out" + os.sep + "cleaned_result.xls"
#可能需要安装 xlwt 模块
data_end_screen.to_excel(excel_path)

print(11)