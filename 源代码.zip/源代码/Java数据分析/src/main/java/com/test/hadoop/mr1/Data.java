package com.test.hadoop.mr1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;

public class Data {
//F:\小学期\Documents\Submission\实训项目提交资料\air_data.csv
	public static void main(String[] args) throws IOException {
		String srcFilestr = "F:\\air_data1.csv";
		String desFilestr = "F:\\cleandata.txt";
		File srcFile = new File(srcFilestr);
		File desFile = new File(desFilestr);
		InputStream fis = new FileInputStream(srcFile);
		OutputStream fos = new FileOutputStream(desFile);
		InputStreamReader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);
		PrintStream ps = new PrintStream(fos);
		String str = "";
		int count = -1;
		while((str = br.readLine()) != null) {
			if(count == -1) {
				ps.println(str);
				count++;
			}
			else {
				int flag01 = 0;//第一年
				int flag02 = 0;//第二年
				int flag03 = 0;//平均折扣
				String[] dataString = str.trim().split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)",-1);
				//第一年票价不为0
				if(dataString[14].length() != 0 && Double.parseDouble(dataString[14]) != 0)
					flag01 = 1;
				//第二年票价不为0
				if(dataString[15].length() != 0 && Double.parseDouble(dataString[15]) != 0)
					flag02 = 1;
				//平均折扣不为0
				if(dataString[28].length() != 0 && Double.parseDouble(dataString[28]) != 0)
					flag03 = 1;
				boolean condition1 = (dataString[14].length() != 0 && dataString[15].length() != 0);
				boolean condition2 = (dataString[16].length() != 0);
				if(condition1 && (flag01 != 0 || flag02 != 0) && condition2 && flag03 != 0) {
					ps.println(str);
					count++;				

				}
			}

		}
		System.out.println(count);
		br.close();
		ps.close();
		isr.close();
		fis.close();
		fos.close();
	}

}
