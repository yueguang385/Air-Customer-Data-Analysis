package com.test.hadoop.mr1.bean;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class JoinBean implements Writable{
	private String ffpDate;  //会员入会时间距观测窗口结束的月数
	private String lastToEnd;  //客户最近一次乘坐公司飞机距观测窗口结束的月数
	private String flightCount;  //客户在观测窗口内乘坐公司飞机的次数
	private String SegKMSum;  //客户在观测窗口内累计的飞行里程
	private String avgDiscount;  //客户在观测窗口内乘坐舱位所对应的折扣系数的平均值
	
	public JoinBean(String ffpDate, String lastToEnd, String flightCount, String segKMSum, String avgDiscount) {
		super();
		this.ffpDate = ffpDate;
		this.lastToEnd = lastToEnd;
		this.flightCount = flightCount;
		SegKMSum = segKMSum;
		this.avgDiscount = avgDiscount;
	}

	public JoinBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getFfpDate() {
		return ffpDate;
	}

	public void setFfpDate(String ffpDate) {
		this.ffpDate = ffpDate;
	}

	public String getLastToEnd() {
		return lastToEnd;
	}

	public void setLastToEnd(String lastToEnd) {
		this.lastToEnd = lastToEnd;
	}

	public String getFlightCount() {
		return flightCount;
	}

	public void setFlightCount(String flightCount) {
		this.flightCount = flightCount;
	}

	public String getSegKMSum() {
		return SegKMSum;
	}

	public void setSegKMSum(String segKMSum) {
		SegKMSum = segKMSum;
	}

	public String getAvgDiscount() {
		return avgDiscount;
	}

	public void setAvgDiscount(String avgDiscount) {
		this.avgDiscount = avgDiscount;
	}

	@Override
	public String toString() {
		return "JoinBean [ffpDate=" + ffpDate + ", lastToEnd=" + lastToEnd + ", flightCount=" + flightCount
				+ ", SegKMSum=" + SegKMSum + ", avgDiscount=" + avgDiscount + "]";
	}

	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.ffpDate);
		out.writeUTF(this.lastToEnd);
		out.writeUTF(this.flightCount);
		out.writeUTF(this.SegKMSum);
		out.writeUTF(this.avgDiscount);
		
	}

	public void readFields(DataInput in) throws IOException {
		this.ffpDate = in.readUTF();
		this.lastToEnd = in.readUTF();
		this.flightCount = in.readUTF();
		this.SegKMSum = in.readUTF();
		this.avgDiscount = in.readUTF();
		
	}
	
	
	
	
	
}
