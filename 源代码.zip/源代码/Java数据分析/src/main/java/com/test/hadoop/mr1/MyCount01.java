package com.test.hadoop.mr1;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

//会员卡级别的人数
public class MyCount01 {
	public static class MyMapper
	  extends Mapper<LongWritable, Text, Text, IntWritable>{

		private final static IntWritable one = new IntWritable(1);
		private Text theWord = new Text();
		private int flag = 0;         //忽略第一行
		@Override
		protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
				throws IOException, InterruptedException {
			
			if(flag == 0) {
				flag = 1;
			}
			else {
				String line = value.toString();
				String[] fields = line.trim().split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)",-1);
				String rank = fields[4];
				theWord.set(rank);
				context.write(theWord, one);
			}
		}
			
	}
	
	public static class MyReducer
	  extends Reducer<Text, IntWritable, Text, LongWritable>{

		@Override
		protected void reduce(Text rank, Iterable<IntWritable> one,
				Reducer<Text, IntWritable, Text, LongWritable>.Context context) throws IOException, InterruptedException {
			
			long count = 0;
			Iterator<IntWritable> iterator = one.iterator();
			while(iterator.hasNext()) {
				IntWritable oneIntWritable = iterator.next();
				count++;
			}
			
			LongWritable num = new LongWritable();
			num.set(count);
			context.write(rank, num);
		}
				
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		if(args != null && args.length < 2) {
			System.out.println("<in>,<out>");
			System.exit(2);
		}
		
		Configuration configuration = new Configuration();
		Job job = Job.getInstance(configuration, "MyCount01");
		job.setJarByClass(MyCount01.class);
		
		FileInputFormat.setInputPaths(job, new Path(args[0]));
	    job.setInputFormatClass(TextInputFormat.class);
		
	    job.setMapperClass(MyMapper.class);	
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
		
	    job.setNumReduceTasks(2);	
		job.setReducerClass(MyReducer.class);
		job.setOutputKeyClass(Text.class);		
		job.setOutputValueClass(LongWritable.class);
		
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setOutputFormatClass(TextOutputFormat.class);
				
		job.submit();	
		boolean result = job.waitForCompletion(true);
		System.exit(result ? 0 : 1);
	}

}
