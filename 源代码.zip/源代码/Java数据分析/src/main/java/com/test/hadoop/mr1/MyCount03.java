package com.test.hadoop.mr1;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

//在五大类中各年龄段的分布
public class MyCount03 {
	public static class MyMapper
	  extends Mapper<LongWritable, Text, Text, IntWritable>{

		private final static IntWritable one = new IntWritable(1);
		@Override
		protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
				throws IOException, InterruptedException {
			
			String age = value.toString();
			int testAge = Integer.parseInt(age);
			String range = "";
			if(testAge >= 0 && testAge < 10)
				range = "10岁以下";
			else
				if(testAge >= 10 && testAge < 20)
					range = "10-20";
				else
					if(testAge >= 20 && testAge < 30)
						range = "20-30";
					else
						if(testAge >= 30 && testAge < 40)
							range = "30-40";
						else
							if(testAge >= 40 && testAge < 50)
								range = "40-50";
							else
								if(testAge >= 50 && testAge < 60)
									range = "50-60";
								else
									if(testAge >= 60 && testAge < 70)
										range = "60-70";
									else
										if(testAge >= 70 && testAge < 80)
											range = "70-80";
										else
											if(testAge >= 80 && testAge < 90)
												range = "80-90";
											else
												if(testAge >= 90 && testAge < 100)
													range = "90-100";
												else
													range = "100+";
											
			Text ageText = new Text();
			ageText.set(range);
			context.write(ageText, one);		                  	
		}
		
	}
	
	public static class MyReducer
	  extends Reducer<Text, IntWritable, Text, LongWritable>{

		@Override
		protected void reduce(Text range, Iterable<IntWritable> one,
				Reducer<Text, IntWritable, Text, LongWritable>.Context context) throws IOException, InterruptedException {
			
			long count = 0;
			Iterator<IntWritable> iterator = one.iterator();
			while(iterator.hasNext()) {
				IntWritable oneIntWritable = iterator.next();
				count++;
			}
			LongWritable result = new LongWritable();
			result.set(count);
			context.write(range, result);
		}
				
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		if(args != null && args.length < 2) {
			System.out.println("<in>,<out>");
			System.exit(2);
		}
		
		Configuration configuration = new Configuration();
		Job job = Job.getInstance(configuration, "MyCount04");
		job.setJarByClass(MyCount03.class);
		
		FileInputFormat.setInputPaths(job, new Path(args[0]));
	    job.setInputFormatClass(TextInputFormat.class);
		
	    job.setMapperClass(MyMapper.class);	
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
		
	    job.setNumReduceTasks(2);	
		job.setReducerClass(MyReducer.class);
		job.setOutputKeyClass(Text.class);		
		job.setOutputValueClass(LongWritable.class);
		
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setOutputFormatClass(TextOutputFormat.class);
		
		job.submit();	
		boolean result = job.waitForCompletion(true);
		System.exit(result ? 0 : 1);
		
		
	}

}
