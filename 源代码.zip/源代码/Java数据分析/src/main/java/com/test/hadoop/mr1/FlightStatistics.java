package com.test.hadoop.mr1;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import com.test.hadoop.mr1.bean.JoinBean;

public class FlightStatistics {
	public static class TestMapper
	  extends Mapper<LongWritable, Text, Text, JoinBean>{
		private int flag = 0;  //第一行数据是字段名字，忽略

		@Override
		protected void map(LongWritable key, Text value,
				Mapper<LongWritable, Text, Text, JoinBean>.Context context)
				throws IOException, InterruptedException {
			if(flag == 0){     //测试第一段
				flag =1;
			}
			else {
				String line = value.toString();
				String[] fields = line.trim().split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)",-1);

				//取各属性数据
				String ffpdate = fields[1];
				String lastToEnd = fields[22];
				String flightCount = fields[10];
				String segKMSum = fields[16];
				String avgDiscount = fields[28];
				String Id = fields[0];
				Text IdText = new Text();
				IdText.set(Id);

				JoinBean joinbean = new JoinBean(ffpdate, lastToEnd, flightCount, segKMSum, avgDiscount);
				context.write(IdText, joinbean);
			}
		}
				
	}
	
	public static class TestReducer
	  extends Reducer<Text, JoinBean, Text, NullWritable>{

		@Override
		protected void reduce(Text Id, Iterable<JoinBean> joinbeans, Reducer<Text, JoinBean, Text, NullWritable>.Context context)
				throws IOException, InterruptedException {
			//Id唯一，每次reduce只有一个数据，不用while循环
			Iterator<JoinBean> iterator = joinbeans.iterator();
			JoinBean joinbean = iterator.next();
			
			//处理时间
			String date = joinbean.getFfpDate();
			String[] dateString = date.split("/");
			String yearString = dateString[0];
			String monthString = dateString[1];
			String dayString = dateString[2];
			
			int year = Integer.parseInt(yearString);
			int month = Integer.parseInt(monthString);
			int day = Integer.parseInt(dayString);
			long ffpdate = ((2014*365 + 3*30 + 31) - (year*365 + month *30 + day))/30;
			String ffpdateString = String.valueOf(ffpdate);
			
			//处理月
			String lastmonthString = joinbean.getLastToEnd();
			int lastmonth = Integer.parseInt(lastmonthString) / 30;
			if(lastmonth == 0)   //不足一个月，按一个月记
				lastmonth = 1;
			lastmonthString = String.valueOf(lastmonth);
			
			String result = Id.toString() + "," + ffpdateString + "," + lastmonthString +
					        "," + joinbean.getFlightCount() + "," + joinbean.getSegKMSum() +
					        "," + joinbean.getAvgDiscount();
			
			Text rs = new Text();
			rs.set(result);
			context.write(rs, null);
			
		}
			
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		if(args != null && args.length < 2) {
			System.out.println("<in>,<out>");
			System.exit(2);
		}
		
		Configuration configuration = new Configuration();
		Job job = Job.getInstance(configuration, "Flight Statistic");
		job.setJarByClass(FlightStatistics.class);
		
		FileInputFormat.setInputPaths(job, new Path(args[0]));
	    job.setInputFormatClass(TextInputFormat.class);
		
	    job.setMapperClass(TestMapper.class);	
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(JoinBean.class);
		
	    job.setNumReduceTasks(2);	
		job.setReducerClass(TestReducer.class);
		job.setOutputKeyClass(Text.class);		
		job.setOutputValueClass(JoinBean.class);
		
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setOutputFormatClass(TextOutputFormat.class);
				
		job.submit();	
		boolean result = job.waitForCompletion(true);
		System.exit(result ? 0 : 1);
	}

}
