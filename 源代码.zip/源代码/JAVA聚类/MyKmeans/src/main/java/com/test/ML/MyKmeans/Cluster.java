package com.test.ML.MyKmeans;
//实现聚类操作
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Cluster {	
	public int num=5;
	public int maxIter = 300;
	public List<Point> points;
	public List<Point> centers;
	
	 public Cluster(int num, int maxIter, List<Point> points) {
	        this.num = num;
	        this.maxIter = maxIter;
	        this.points = points;
	        initCenters();
	 }
	 public void initCenters()//初始化聚类中心
	    {
	        centers = new ArrayList<Point>(num);

	        for (int i = 0; i < num; i++)
	        {
	            Point tmPoint = points.get(new Random().nextInt(62040));
	            Point center = new Point(tmPoint.getId(), tmPoint.getLi(),tmPoint.getRi(), tmPoint.getFi(),tmPoint.getMS(),tmPoint.getCi());
	            center.setCla(i + 1);
	            centers.add(center);
	        }
	    }
	 public void runKmeans()
	    {
	        // 已迭代次数
	        int count = 1;

	        while (count++ <= maxIter)//迭代终止条件
	        {
	            // 遍历每个点，确定其所属簇
	            for (Point point : points)
	            {
	                assignPointToCluster(point);
	            }
	            //调整中心点
	            adjustCenters();
	        }
	    }
	 public void adjustCenters()//更新聚簇中心坐标
	    {
	        double sumLi[] = new double[num];
	        double sumRi[] = new double[num];
	        double sumFi[] = new double[num];
	        double sumMS[] = new double[num];
	        double sumCi[] = new double[num];
	        
	        
	        int count[] = new int[num];

	        // 保存每个簇的横纵坐标之和
	        for (int i = 0; i < num; i++)
	        {
	            sumLi[i] = 0.0;
	            sumRi[i] = 0.0;
	            sumFi[i] = 0.0;
	            sumMS[i] = 0.0;
	            sumCi[i] = 0.0;
	            count[i] = 0;
	        }

	        // 计算每个簇的横纵坐标总和、记录每个簇的个数
	        for (Point point : points)
	        {
	            int clusterID = point.getCla();

	            // System.out.println(clusterID);
	            sumLi[clusterID - 1] += point.getLi();
	            sumRi[clusterID - 1] += point.getRi();
	            sumFi[clusterID - 1] += point.getFi();
	            sumMS[clusterID - 1] += point.getMS();
	            sumCi[clusterID - 1] += point.getCi();
	            count[clusterID - 1]++;
	        }

	        // 更新簇心坐标
	        for (int i = 0; i < num; i++)
	        {
	            Point tmpPoint = centers.get(i);
	            tmpPoint.setLi(sumLi[i]/count[i]);
	            tmpPoint.setRi(sumRi[i]/count[i]);
	            tmpPoint.setFi(sumFi[i]/count[i]);
	            tmpPoint.setMS(sumMS[i]/count[i]);
	            tmpPoint.setCi(sumCi[i]/count[i]);
	            tmpPoint.setCla(i+1);
	            centers.set(i, tmpPoint);
	        }
            
	    }
	 public void assignPointToCluster(Point point)
	    {
	        double minDistance = 1000000;
	        int clusterID = -1;

	        for (Point center : centers)
	        {
	            double dis = EurDistance(point, center);
	            if (dis < minDistance)
	            {
	                minDistance = dis;
	                clusterID = center.getCla();
	            }
	        }
	        point.setCla(clusterID);

	    }

	    //欧式距离，计算两点距离
	    public double EurDistance(Point point, Point center)
	    {
	    	//进行归一化
	        double detLi = point.getLi() - center.getLi();
	        double detLii=(detLi-12)/102;
	        double detRi = point.getRi() - center.getRi();
	        double detRii=(detRi-1)/23;
	        double detFi = point.getFi() - center.getFi();
	        double detFii=(detFi-2)/211;
	        double detMS = point.getMS() - center.getMS();
	        double detMSS=(detMS-368)/580349;
	        double detCi = point.getCi() - center.getCi();
	        double detCii=(detCi-0.136)/1.364;
	        return Math.sqrt(detLii * detLii + detRii * detRii+ detFii * detFii+ detMSS * detMSS+ detCii * detCii);
	    }
}
	
	 






