package com.test.ML.MyKmeans;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import com.test.ML.MyKmeans.Point;
public class TTT {
    public static void main(String[] args) throws NumberFormatException, IOException {
    	double Limax=-1000;
        double Rimax=-1000;
        double Fimax=-1000;
        double MSmax=-1000;
        double Cimax=-1000;
    	double Limin=100000;
    	double Rimin=100000;
    	double Fimin=100000;
    	double MSmin=100000;
    	double Cimin=100000;
    	List<Point>points = new ArrayList<Point>(62044);
        String path = "F://kmeans//result.txt";
        Reader fr=new FileReader(path);//里氏替换，将子类的实例赋予父类的对象
    	BufferedReader br=new BufferedReader(fr);
    	String line=null;
    	while((line=br.readLine())!=null) {
    		String []propers=line.split(",");
    		long id=Long.parseLong(propers[0]);
    		double li=Double.parseDouble(propers[1]);
    		double ri=Double.parseDouble(propers[2]);
    		double fi=Double.parseDouble(propers[3]);
    		double mS=Double.parseDouble(propers[4]);
    		double ci=Double.parseDouble(propers[5]);
    		Point tmpPoint=new Point(id, li, ri, fi, mS, ci);
    		points.add(tmpPoint);		
    	}
        br.close();
        fr.close();
        for (Point point : points)
        {   if(point.getLi()>Limax) {Limax=point.getLi();}
            if(point.getRi()>Rimax) {Rimax=point.getRi();}
            if(point.getFi()>Fimax) {Fimax=point.getFi();}
            if(point.getMS()>MSmax) {MSmax=point.getMS();}
            if(point.getCi()>Cimax) {Cimax=point.getCi();}
            if(point.getLi()<Limin) {Limin=point.getLi();}
            if(point.getRi()<Rimin) {Rimin=point.getRi();}
            if(point.getFi()<Fimin) {Fimin=point.getFi();}
            if(point.getMS()<MSmin) {MSmin=point.getMS();}
            if(point.getCi()<Cimin) {Cimin=point.getCi();}
         }
        
        System.out.println(Limax);
        System.out.println(Rimax);
        System.out.println(Fimax);
        System.out.println(MSmax);
        System.out.println(Cimax);
        System.out.println(Limin);
        System.out.println(Rimin);
        System.out.println(Fimin);
        System.out.println(MSmin);
        System.out.println(Cimin);
    	

		
	}
    
}
