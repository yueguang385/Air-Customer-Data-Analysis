package com.test.ML.MyKmeans;

public class Point {
	private long id;
	private double Li;
	private double Ri;
	private double Fi;
	private double MS;
	private double Ci;
	private int cla=-1;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getLi() {
		return Li;
	}
	public void setLi(double li) {
		Li = li;
	}
	public double getRi() {
		return Ri;
	}
	public void setRi(double ri) {
		Ri = ri;
	}
	public double getFi() {
		return Fi;
	}
	public void setFi(double fi) {
		Fi = fi;
	}
	public double getMS() {
		return MS;
	}
	public void setMS(double mS) {
		MS = mS;
	}
	public double getCi() {
		return Ci;
	}
	public void setCi(double ci) {
		Ci = ci;
	}
	public int getCla() {
		return cla;
	}
	public void setCla(int cla) {
		this.cla = cla;
	}
	public Point() {
		super();
	}
	public Point(Long id, double li, double ri, double fi, double mS, double ci) {
		super();
		this.id = id;
		Li = li;
		Ri = ri;
		Fi = fi;
		MS = mS;
		Ci = ci;
	}
	@Override
	public String toString() {	
		return  "Point [id="+id+",Li="+Li+",Ri="+Ri+",Fi="+Fi+",MS="+MS+",Ci="+Ci+",cla="+cla+"]";
	}

}
