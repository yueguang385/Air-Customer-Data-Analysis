package com.test.clean;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Clean3Data {
	public static void main(String[] args) throws IOException {
		String srcFileStr="C:\\Users\\asus\\Desktop\\startdata\\cleaned_data.csv";
		String destFileStr="C:\\Users\\asus\\Desktop\\tempdata\\cleaned_twice_data_age.csv";
		
		FileReader fr = new FileReader(srcFileStr);
		FileWriter fw = new FileWriter(destFileStr);
		BufferedReader bReader = new BufferedReader(fr);
		BufferedWriter bWriter = new BufferedWriter(fw);
		
		String line = null;
		bReader.readLine();
		while((line = bReader.readLine())!= null)
		{
			String [] words = line.trim().split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)",-1);
			bWriter.write(words[0]+","+words[9]);
			bWriter.newLine();
			bWriter.flush();
		}
		fr.close();
		bReader.close();
		fw.close();
		bWriter.close();
	}

}
