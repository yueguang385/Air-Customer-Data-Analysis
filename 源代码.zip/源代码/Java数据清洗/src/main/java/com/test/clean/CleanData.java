package com.test.clean;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CleanData {
public static void main(String[] args) throws IOException {
	String srcFileStr="C:\\Users\\asus\\Desktop\\startdata\\cleaned_data.csv";
	String destFileStr="C:\\Users\\asus\\Desktop\\tempdata\\cleaned_twice_data.csv";
	FileReader fr = new FileReader(srcFileStr);
	FileWriter fw = new FileWriter(destFileStr);
	BufferedReader bReader = new BufferedReader(fr);
	BufferedWriter bWriter = new BufferedWriter(fw);
	
	String line = null;
	String[] provinces = {"北京市","天津市","上海市","重庆市","河北省","山西省","辽宁省","吉林省",
			"黑龙江省","江苏省","浙江省","安徽省","福建省","江西省","山东省","河南省","湖北省","湖南省","广东省",
			"海南省","四川省","贵州省","云南省","陕西省","甘肃省","青海省","内蒙古自治区","广西壮族自治区","西藏自治区",
			"宁夏回族自治区","新疆维吾尔自治区"};
	String[] standard = {"北京","天津","上海","重庆","河北","山西","辽宁","吉林","黑龙江","江苏","浙江","安徽","福建",
			"江西","山东","河南","湖北","湖南","广东","海南","四川","贵州","云南","陕西","甘肃","青海","内蒙古","广西",
			"西藏","宁夏","新疆"};
	while((line = bReader.readLine())!= null)
	{
		String [] words = line.split(",");
		if(words[8].equals("CN")) {
			if (words[7].equals("")||words[7].equals("-"))
				continue;
			String out = null;
			if(words[6].equals("北京")||words[7].equals("北京"))
				words[7]="北京";
			if(words[6].equals("天津")||words[7].equals("天津"))
				words[7]="天津";
			if(words[6].equals("上海")||words[7].equals("上海"))
				words[7]="上海";
			if(words[6].equals("重庆")||words[7].equals("重庆"))
				words[7]="重庆";
			for(int i=0;i<31;i++)
			{
				if(words[7].equals(provinces[i]))
				{
					words[7]=standard[i];
					break;
				}
			}
			boolean del = true;
			for(int i=0;i<31;i++)
			{
				if(words[7].equals(standard[i]))
				{
					del=false;
					break;
				}
			}
			if(del)
				continue;
			out = words[0]+","+words[7];
			bWriter.write(out);
			bWriter.newLine();
			bWriter.flush();
		}
		//54513
	}
	fr.close();
	bReader.close();
	fw.close();
	bWriter.close();
}
}