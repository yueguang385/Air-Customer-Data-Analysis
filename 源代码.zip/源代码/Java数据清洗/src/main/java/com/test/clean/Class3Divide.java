package com.test.clean;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Class3Divide {
	public static void main(String[] args) throws IOException {
		String srcFileStr="C:\\Users\\asus\\Desktop\\startdata\\cluster1.txt";
		String destFileStr="C:\\Users\\asus\\Desktop\\finaldata\\cluster1age.txt";
		String srcFileStr1="C:\\Users\\asus\\Desktop\\startdata\\cluster2.txt";
		String destFileStr1="C:\\Users\\asus\\Desktop\\finaldata\\cluster2age.txt";
		String srcFileStr2="C:\\Users\\asus\\Desktop\\startdata\\cluster3.txt";
		String destFileStr2="C:\\Users\\asus\\Desktop\\finaldata\\cluster3age.txt";
		String srcFileStr3="C:\\Users\\asus\\Desktop\\startdata\\cluster4.txt";
		String destFileStr3="C:\\Users\\asus\\Desktop\\finaldata\\cluster4age.txt";
		String srcFileStr4="C:\\Users\\asus\\Desktop\\startdata\\cluster5.txt";
		String destFileStr4="C:\\Users\\asus\\Desktop\\finaldata\\cluster5age.txt";
		
		String src = "C:\\Users\\asus\\Desktop\\tempdata\\cleaned_twice_data_age.csv";
		FileReader fr = new FileReader(src);
		BufferedReader bReader = new BufferedReader(fr);
		
		String [] a = new String[70000] ;
		String [] a1 = new String[70000];
		String line = null ;
		int i = 0;
		while((line = bReader.readLine())!= null){
			//System.out.println(i);
			
			String b[] = line.split(",");
			if(b.length!=2)
				continue;
			//if(!(b[1].equals("男")||b[1].equals("女")))
				//continue;
			//System.out.println(b[0]+b[1]);
			a[i]=b[0]+" ";
			a1[i]=b[1];
			i++;
		}
		fr.close();
		bReader.close();
		System.out.println("20% finished!");
		
		FileWriter fw = new FileWriter(destFileStr);
		BufferedWriter bWriter = new BufferedWriter(fw);
		FileWriter fw1 = new FileWriter(destFileStr1);
		BufferedWriter bWriter1 = new BufferedWriter(fw1);
		FileWriter fw2 = new FileWriter(destFileStr2);
		BufferedWriter bWriter2 = new BufferedWriter(fw2);
		FileWriter fw3 = new FileWriter(destFileStr3);
		BufferedWriter bWriter3 = new BufferedWriter(fw3);
		FileWriter fw4 = new FileWriter(destFileStr4);
		BufferedWriter bWriter4 = new BufferedWriter(fw4);
		
		FileReader fr1 = new FileReader(srcFileStr);
		BufferedReader br1 = new BufferedReader(fr1);
		FileReader fr2 = new FileReader(srcFileStr1);
		BufferedReader br2 = new BufferedReader(fr2);
		FileReader fr3 = new FileReader(srcFileStr2);
		BufferedReader br3 = new BufferedReader(fr3);
		FileReader fr4 = new FileReader(srcFileStr3);
		BufferedReader br4 = new BufferedReader(fr4);
		FileReader fr5 = new FileReader(srcFileStr4);
		BufferedReader br5 = new BufferedReader(fr5);
		
		while((line = br1.readLine())!= null){
			String [] divided = line.split(",");
			//System.out.println(divided[0]);
			for(int k = 0;k<70000;k++) {
				if(line.equals(a[k])) {
					bWriter.write(a1[k]);
					bWriter.newLine();
					bWriter.flush();
					break;
				}
			}
		}
		fw.close();
		bWriter.close();
		System.out.println("50% finished!");
		
		while((line = br2.readLine())!= null){
			String [] divided = line.split(",");
			//System.out.println(divided[0]);
			for(int k = 0;k<70000;k++) {
				if(line.equals(a[k])) {
					bWriter1.write(a1[k]);
					bWriter1.newLine();
					bWriter1.flush();
					break;
				}
			}
		}
		fw1.close();
		bWriter1.close();
		System.out.println("60% finished!");
		
		while((line = br3.readLine())!= null){
			String [] divided = line.split(",");
			//System.out.println(divided[0]);
			for(int k = 0;k<70000;k++) {
				if(line.equals(a[k])) {
					bWriter2.write(a1[k]);
					bWriter2.newLine();
					bWriter2.flush();
					break;
				}
			}
		}
		fw2.close();
		bWriter2.close();
		System.out.println("70% finished!");
		
		while((line = br4.readLine())!= null){
			String [] divided = line.split(",");
			//System.out.println(divided[0]);
			for(int k = 0;k<70000;k++) {
				if(line.equals(a[k])) {
					bWriter3.write(a1[k]);
					bWriter3.newLine();
					bWriter3.flush();
					break;
				}
			}
		}
		fw3.close();
		bWriter3.close();
		System.out.println("80% finished!");
		
		while((line = br5.readLine())!= null){
			String [] divided = line.split(",");
			//System.out.println(divided[0]);
			for(int k = 0;k<70000;k++) {
				if(line.equals(a[k])) {
					bWriter4.write(a1[k]);
					bWriter4.newLine();
					bWriter4.flush();
					break;
				}
			}
		}
		fw4.close();
		bWriter4.close();
		System.out.println("100% finished!");
	}
}
